import java.awt.*;
import java.applet.*;
public class smiley extends Applet{
public void paint(Graphics g)
{
g.drawArc(60,125,80,40,180,180);
g.setColor(Color.red);
g.fillArc(30,55,60,50,0,180);
}
}

import java.applet.Applet;
import java.awt.Color;
import java.awt.Graphics;

public class OlympicRingsApplet extends Applet {

    public void paint(Graphics g) {
        // Set color for the rings
        g.setColor(Color.BLUE);
        // Draw the first ring (Blue)
        g.drawOval(50, 50, 100, 100);

        g.setColor(Color.BLACK);
        // Draw the second ring (Black)
        g.drawOval(160, 50, 100, 100);

        g.setColor(Color.RED);
        // Draw the third ring (Red)
        g.drawOval(270, 50, 100, 100);

        g.setColor(Color.YELLOW);
        // Draw the fourth ring (Yellow)
        g.drawOval(105, 100, 100, 100);

        g.setColor(Color.GREEN);
        // Draw the fifth ring (Green)
        g.drawOval(215, 100, 100, 100);
    }
}

import java.awt.*;

public class TrafficLightApplet extends Applet {
    public void paint(Graphics g) {
        setSize(200, 300);
        g.setColor(Color.RED);
        g.fillOval(50, 50, 100, 100);
        g.setColor(Color.YELLOW);
        g.fillOval(50, 170, 100, 100);
        g.setColor(Color.GREEN);
        g.fillOval(50, 290, 100, 100);
    }
}
import java.applet.Applet;
import java.awt.Graphics;
import java.awt.Color;

public class kite extends Applet {

    @Override
    public void paint(Graphics g) {
        // Set color to blue
        g.setColor(Color.blue);

        // Draw triangle at top
        g.fillPolygon(new int[] { 100, 300, 200 }, new int[] { 0, 100, 100 }, 3);

        // Draw rectangle at middle
        g.fillRect(100, 100, 200, 100);

        // Draw triangle at bottom
        g.fillPolygon(new int[] { 200, 300, 300 }, new int[] { 200, 200, 300 }, 3);

        // Draw left vertical line
        g.fillRect(100, 0, 100, 300);

        // Draw right vertical line
        g.fillRect(300, 0, 100, 300);
    }
}
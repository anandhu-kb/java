import java.awt.*;
import java.applet.*;
public class HumanFace extends Applet{
public void paint(Graphics g)
{
g.drawOval(40,40,120,150);
g.drawOval(57,75,30,20);
g.drawOval(110,75,30,20);
g.fillOval(68,81,10,10);
g.fillOval(121,81,10,10);
g.drawArc(60,125,80,40,180,180);
g.fillOval(68,81,10,10);
g.drawOval(40,40,120,150);
g.drawOval(40,40,120,150);
}
}


import java.io.*;
import java.lang.*;
import java.util.*;

class ExceptionTryCatch {
    public static void main(String[] args) {
        // Example of ArithmeticException
        try {
            int res = 10 / 0;
        } catch (ArithmeticException e) {
            System.out.println("ArithmeticException caught: " + e);
        }

        // Example of ArrayIndexOutOfBoundsException
        try {
            int[] arr = new int[5];
            arr[5] = 20;
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("ArrayIndexOutOfBoundsException caught: " + e);
        }

        // Example of ArrayStoreException
        try {
            Integer[] intArr = new Integer[10];
            List<String> strList = Arrays.asList("Hello", "World");
            System.arraycopy(strList.toArray(), 0, intArr, 0, 2);
        } catch (ArrayStoreException e) {
            System.out.println("ArrayStoreException caught: " + e);
        }

        // Example of FileNotFoundException
        try {
            File file = new File("nonexistent.txt");
            FileReader fr = new FileReader(file);
        } catch (FileNotFoundException e) {
            System.out.println("FileNotFoundException caught: " + e);
        }

        // Example of IOException
        try {
            FileReader fr = new FileReader("file.txt");
            fr.read();
        } catch (IOException e) {
            System.out.println("IOException caught: " + e);
        }

        // Example of StringIndexOutOfBoundsException
        try {
            String str = "Hello";
            char ch = str.charAt(5);
        } catch (StringIndexOutOfBoundsException e) {
            System.out.println("StringIndexOutOfBoundsException caught: " + e);
        }
    }
}
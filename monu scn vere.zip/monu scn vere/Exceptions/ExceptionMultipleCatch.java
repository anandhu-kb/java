import java.lang.*;
import java.io.*;
import java.util.*;
public class ExceptionMultipleCatch {

      public static void main(String[] args) {
        // Example of ArithmeticException
        try {
            int res = 10 / 0;
        } 
        catch (ArithmeticException e) {
            System.out.println("ArithmeticException caught: " + e);
        }
        catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("ArrayIndexOutOfBoundsException caught: " + e);
        }

        // Example of ArrayStoreException
        catch (ArrayStoreException e) {
            System.out.println("ArrayStoreException caught: " + e);
        }

        System.out.println("Program continues to run.");
    }

    public static void divisionMethod() throws ArithmeticException {
        int result = 10 / 0;
    }
}
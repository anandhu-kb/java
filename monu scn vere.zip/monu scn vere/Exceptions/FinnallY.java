import java.io.*;
import java.util.*;
import java.lang.*;
public class FinnallY {

    public static void main(String[] args) {
        try {
            System.out.println("Inside try block");
            int b = 30 / 0; // it will generate an exception
        } catch (ArithmeticException e) {
            System.out.println("ArithmeticException Caught: " + e.getMessage());
        } finally {
            System.out.println("Inside finally block");
        }
    }
}
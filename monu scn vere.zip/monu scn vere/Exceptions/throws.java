public class ThrowS {
    static void checkCondition(boolean condition) throws Exception {
        if (condition) {
            throw new Exception("Condition is true");
        }
    }

    public static void main(String[] args) {
        try {
            checkCondition(true);
        } catch (Exception e) {
            System.out.println("Caught the exception.");
            System.out.println(e.getMessage());
        }
    }
}
class ThroW {
static void avg()
{
    try{
        throw new ArithmeticException("demo");

    }
    catch(ArithmeticException e)
    {
        System.out.println("Exception Caught: " +e);
    }

}
public static void main(String args[])
{
    avg();
}
}
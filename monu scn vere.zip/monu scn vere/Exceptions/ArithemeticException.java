import java.lang.*;
import java.io.*;
import java.util.*;
class ArithmeticException {
    public static void main(String[] args) {

        // Example of ArrayStoreException
        try {
            Integer[] intArr = new Integer[10];
            List<String> strList = Arrays.asList("Hello", "World");
            System.arraycopy(strList.toArray(), 0, intArr, 0, 2);
        } catch (ArrayStoreException e) {
            System.out.println("ArrayStoreException caught: " + e);
        }
    }}
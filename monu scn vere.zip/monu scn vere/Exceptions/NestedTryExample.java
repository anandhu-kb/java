public class NestedTryExample {

    public static void main(String[] args) {
        try {
            // code block 1
            int a = 5 / 0;

            try {
                // code block 2
                int b = 10 / 2;

                try {
                    // code block 3
                    int[] c = new int[5];
                    int d = c[6]; // this line will cause an ArrayIndexOutOfBoundsException
                } catch (ArrayIndexOutOfBoundsException e) {
                    System.out.println("ArrayIndexOutOfBoundsException caught in code block 3: " + e);
                }
            } catch (ArithmeticException e) {
                System.out.println("ArithmeticException caught in code block 2: " + e);
            }
        } catch (ArithmeticException e) {
            System.out.println("ArithmeticException caught in code block 1: " + e);
        }
    }
}
class Animal {
    void sound() {
        System.out.println("The animal makes a sound");
    }
}

class Cat extends Animal {
    @Override
    void sound() {
        System.out.println("The cat meows");
    }
}

class Dog extends Animal {
    @Override
    void sound() {
        System.out.println("The dog barks");
    }
}

public class Main {
    public static void main(String[] args) {
        Animal myAnimal = new Animal();
        Animal myCat = new Cat();
        Animal myDog = new Dog();

        myAnimal.sound();
        myCat.sound();
        myDog.sound();
    }
}
import java.util.Scanner;

// Base class Office
class Office {
    int empNo;
    String empName;
    double salary;

    // Default constructor
    public Office() {
        // Default constructor
    }

    // Parameterized constructor
    public Office(int empNo, String empName, double salary) {
        this.empNo = empNo;
        this.empName = empName;
        this.salary = salary;
    }

    // Method to get values
    public void getValue() {
        System.out.println("Employee Number: " + empNo);
        System.out.println("Employee Name: " + empName);
        System.out.println("Salary: " + salary);
    }
}

// Subclass Teaching extending Office
class Teaching extends Office {
    String designation;

    // Method to set values
    public void setValue() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter Teaching Designation: ");
        designation = scanner.nextLine();

        // Set values inherited from the base class
        System.out.print("Enter Employee Number: ");
        empNo = scanner.nextInt();

        System.out.print("Enter Employee Name: ");
        empName = scanner.next();

        System.out.print("Enter Salary: ");
        salary = scanner.nextDouble();
    }
}

// Subclass NonTeaching extending Office
class NonTeaching extends Office {
    String designation;

    // Method to set values
    public void setValue() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter Non-Teaching Designation: ");
        designation = scanner.nextLine();

        // Set values inherited from the base class
        System.out.print("Enter Employee Number: ");
        empNo = scanner.nextInt();

        System.out.print("Enter Employee Name: ");
        empName = scanner.next();

        System.out.print("Enter Salary: ");
        salary = scanner.nextDouble();
    }
}

// Main class
public class hi {
    public static void main(String[] args) {
        Teaching teachingStaff = new Teaching();
        NonTeaching nonTeachingStaff = new NonTeaching();

        System.out.println("Enter details for Teaching Staff:");
        teachingStaff.setValue();
        System.out.println("\nTeaching Staff Details:");
        teachingStaff.getValue();

        System.out.println("\nEnter details for Non-Teaching Staff:");
        nonTeachingStaff.setValue();
        System.out.println("\nNon-Teaching Staff Details:");
        nonTeachingStaff.getValue();
    }
}


import java.util.Scanner;

// Define the Department interface
interface Department {
    void showData();
}

// Define the Hostel class
class Hostel {
    String hostelname;
    String hostellocation;
    int noofrooms;

    // Method to read Hostel details
    void readData() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Hostel Name: ");
        hostelname = scanner.nextLine();
        System.out.print("Enter Hostel Location: ");
        hostellocation = scanner.nextLine();
        System.out.print("Enter Number of Rooms: ");
        noofrooms = scanner.nextInt();
    }

    // Method to print Hostel details
    void printData() {
        System.out.println("Hostel Name: " + hostelname);
        System.out.println("Hostel Location: " + hostellocation);
        System.out.println("Number of Rooms: " + noofrooms);
    }
}

// Define the Student class implementing the Department interface and extending Hostel
class Student extends Hostel implements Department {
    String studname;
    String regno;
    String electivesub;
    double avgmark;

    // Method to read Student details
    void getData() {
        readData();
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Student Name: ");
        studname = scanner.nextLine();
        System.out.print("Enter Registration Number: ");
        regno = scanner.nextLine();
        System.out.print("Enter Elective Subject: ");
        electivesub = scanner.nextLine();
        System.out.print("Enter Average Mark: ");
        avgmark = scanner.nextDouble();
    }

    // Method to print Student details
    public void showData() {
        System.out.println("Student Name: " + studname);
        System.out.println("Registration Number: " + regno);
        System.out.println("Elective Subject: " + electivesub);
        System.out.println("Average Mark: " + avgmark);
        printData();
    }
}

// Main class for testing
public class Main {
    public static void main(String[] args) {
        // Example Usage
        Student student = new Student();
        student.getData();
        System.out.println("\nStudent Details:");
        student.showData();
    }
}

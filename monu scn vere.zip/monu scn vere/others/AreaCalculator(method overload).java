import java.util.Scanner;

public class AreaCalculator {

    // Method to calculate the area of a rectangle
    public static double calculateRectangleArea(double length, double width) {
        return length * width;
    }

    // Method to calculate the area of a square (overloaded version)
    public static double calculateSquareArea(double side) {
        return side * side;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Choose a shape to calculate area:");
        System.out.println("1. Rectangle");
        System.out.println("2. Square");
        System.out.print("Enter your choice (1 or 2): ");

        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                // Rectangle input
                System.out.print("Enter the length of the rectangle: ");
                double length = scanner.nextDouble();

                System.out.print("Enter the width of the rectangle: ");
                double width = scanner.nextDouble();

                // Calculate and display the area of the rectangle
                double rectangleArea = calculateRectangleArea(length, width);
                System.out.println("Area of Rectangle: " + rectangleArea);
                break;

            case 2:
                // Square input
                System.out.print("Enter the side length of the square: ");
                double side = scanner.nextDouble();

                // Calculate and display the area of the square
                double squareArea = calculateSquareArea(side);
                System.out.println("Area of Square: " + squareArea);
                break;

            default:
                System.out.println("Invalid choice. Please enter 1 or 2.");
        }
    }
}

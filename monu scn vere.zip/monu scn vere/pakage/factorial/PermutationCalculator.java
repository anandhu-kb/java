import factorial.Factorial;
import java.util.Scanner;

public class PermutationCalculator {
    public static long calculatePermutation(int n, int r) {
        long nFactorial = Factorial.calculateFactorial(n);
        long nMinusRFactorial = Factorial.calculateFactorial(n - r);

        return nFactorial / nMinusRFactorial;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the value of n: ");
        int n = scanner.nextInt();

        System.out.print("Enter the value of r: ");
        int r = scanner.nextInt();

        if (n < 0 || r < 0 || r > n) {
            System.out.println("Invalid input. Please ensure 0 <= r <= n.");
        } else {
            long permutationResult = calculatePermutation(n, r);
            System.out.println("Permutation (nPr): " + permutationResult);
        }
    }
}

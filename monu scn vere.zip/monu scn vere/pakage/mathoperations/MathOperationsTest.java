// Menu-driven program using the mathoperations package
import java.util.Scanner;
import mathoperations.MathOperations;

public class MathOperationsTest {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int choice;
        int num1, num2, result;

        do {
            System.out.println("Math Operations Menu:");
            System.out.println("1. Addition");
            System.out.println("2. Subtraction");
            System.out.println("3. Multiplication");
            System.out.println("4. Division");
            System.out.println("5. Modulus");
            System.out.println("0. Exit");

            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            if (choice >= 1 && choice <= 5) {
                System.out.print("Enter first number: ");
                num1 = scanner.nextInt();
                System.out.print("Enter second number: ");
                num2 = scanner.nextInt();

                switch (choice) {
                    case 1:
                        result = MathOperations.add(num1, num2);
                        System.out.println("Result: " + result);
                        break;
                    case 2:
                        result = MathOperations.subtract(num1, num2);
                        System.out.println("Result: " + result);
                        break;
                    case 3:
                        result = MathOperations.multiply(num1, num2);
                        System.out.println("Result: " + result);
                        break;
                    case 4:
                        result = MathOperations.divide(num1, num2);
                        System.out.println("Result: " + result);
                        break;
                    case 5:
                        result = MathOperations.modulus(num1, num2);
                        System.out.println("Result: " + result);
                        break;
                }
            } else if (choice != 0) {
                System.out.println("Invalid choice. Please enter a valid option.");
            }

        } while (choice != 0);

        System.out.println("Program terminated.");
        scanner.close();
    }
}


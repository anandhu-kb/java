import java.util.Scanner;

// PrimeCheck.java (inside the primecheck package)
class PrimeCheck {
    public static boolean isPrime(int number) {
        if (number <= 1) {
            return false;
        }

        for (int i = 2; i <= Math.sqrt(number); i++) {
            if (number % i == 0) {
                return false;
            }
        }

        return true;
    }
}

// DigitPrimeCheck.java (inside the primecheck package)
class DigitPrimeCheck {
    public static boolean areAllDigitsPrime(int number) {
        String numString = Integer.toString(number);

        for (int i = 0; i < numString.length(); i++) {
            int digit = Character.getNumericValue(numString.charAt(i));
            if (!PrimeCheck.isPrime(digit)) {
                return false;
            }
        }

        return true;
    }
}

// MainProgram.java
public class primepackage {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a number: ");
        int number = scanner.nextInt();

        if (PrimeCheck.isPrime(number)) {
            System.out.println(number + " is a prime number.");

            if (DigitPrimeCheck.areAllDigitsPrime(number)) {
                System.out.println("All digits of " + number + " are prime.");
            } else {
                System.out.println("Not all digits of " + number + " are prime.");
            }
        } else {
            System.out.println(number + " is not a prime number.");
        }
    }
}

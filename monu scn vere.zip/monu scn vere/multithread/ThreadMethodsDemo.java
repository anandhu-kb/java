class YieldThread extends Thread {
    public void run() {
        for (int i = 1; i <= 5; i++) {
            System.out.println("YieldThread: " + i);
            Thread.yield(); // yield control to another thread
        }
        System.out.println("YieldThread Finished");
    }
}

class SleepThread extends Thread {
    public void run() {
        for (int i = 1; i <= 5; i++) {
            System.out.println("SleepThread: " + i);
            try {
                Thread.sleep(1000); // sleep for 1 second
            } catch (InterruptedException e) {
                System.out.println(e);
            }
        }
        System.out.println("SleepThread Finished");
    }
}

class StopThread extends Thread {
    private volatile boolean isRunning = true;

    public void run() {
        while (isRunning) {
            System.out.println("StopThread is running...");
        }
        System.out.println("StopThread Finished");
    }

    public void stopThread() {
        isRunning = false;
    }
}

public class ThreadMethodsDemo {
    public static void main(String[] args) {
        // Demonstrate yield()
        YieldThread yieldThread = new YieldThread();
        yieldThread.start();

        // Demonstrate sleep()
        SleepThread sleepThread = new SleepThread();
        sleepThread.start();

        // Demonstrate stop()
        StopThread stopThread = new StopThread();
        stopThread.start();

        try {
            Thread.sleep(3000); // Let threads run for a while
        } catch (InterruptedException e) {
            System.out.println(e);
        }

        // Stop StopThread using stopThread() method
        stopThread.stopThread();
    }
}

class OddEvenPrinter implements Runnable {
    private final int start;
    private final int end;
    private final int delay;

    public OddEvenPrinter(int start, int end, int delay) {
        this.start = start;
        this.end = end;
        this.delay = delay;
    }

    @Override
    public void run() {
        for (int i = start; i <= end; i += 2) {
            System.out.println(Thread.currentThread().getName() + ": " + i);

            try {
                Thread.sleep(delay);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

public class Main {
    public static void main(String[] args) {
        // Create two instances of OddEvenPrinter with different ranges and delays
        OddEvenPrinter oddPrinter = new OddEvenPrinter(1, 10, 1000);
        OddEvenPrinter evenPrinter = new OddEvenPrinter(2, 10, 1000);

        // Create two threads
        Thread oddThread = new Thread(oddPrinter, "OddThread");
        Thread evenThread = new Thread(evenPrinter, "EvenThread");

        // Start the threads
        oddThread.start();
        evenThread.start();
    }
}


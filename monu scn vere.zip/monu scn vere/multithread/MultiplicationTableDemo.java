class MultiplicationTablePrinter extends Thread {
    private final int number;
    private final int delay;

    public MultiplicationTablePrinter(int number, int delay) {
        this.number = number;
        this.delay = delay;
    }

    public void run() {
        for (int i = 1; i <= 10; i++) {
            System.out.println(number + " * " + i + " = " + (number * i));
            try {
                Thread.sleep(delay);
            } catch (InterruptedException e) {
                System.out.println(e);
            }
        }
    }
}

public class MultiplicationTableDemo {
    public static void main(String[] args) {
        MultiplicationTablePrinter table2 = new MultiplicationTablePrinter(2, 500); // delay of 500 milliseconds
        MultiplicationTablePrinter table5 = new MultiplicationTablePrinter(5, 1000); // delay of 1000 milliseconds

        table2.start();
        table5.start();
    }
}

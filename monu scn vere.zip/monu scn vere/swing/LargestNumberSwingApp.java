import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LargestNumberSwingApp extends JFrame {

    private JTextField inputField1;
    private JTextField inputField2;
    private JTextField resultField;

    public LargestNumberSwingApp() {
        // Set up the JFrame
        setTitle("Largest Number Finder");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 150);
        setLayout(new GridLayout(4, 1));

        // Create components
        JLabel label1 = new JLabel("Enter Value 1:");
        inputField1 = new JTextField();
        JLabel label2 = new JLabel("Enter Value 2:");
        inputField2 = new JTextField();
        JLabel resultLabel = new JLabel("Largest Number:");
        resultField = new JTextField();
        resultField.setEditable(false); // Make result field read-only

        JButton findButton = new JButton("Find Largest");
        findButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                findLargestNumber();
            }
        });

        // Add components to the frame
        add(label1);
        add(inputField1);
        add(label2);
        add(inputField2);
        add(findButton);
        add(resultLabel);
        add(resultField);

        // Set up the JFrame visibility
        setLocationRelativeTo(null); // Center the frame on the screen
        setVisible(true);
    }

    private void findLargestNumber() {
        try {
            // Get the input values from the input fields
            String inputText1 = inputField1.getText().trim();
            String inputText2 = inputField2.getText().trim();

            // Parse the input text to integers
            int value1 = Integer.parseInt(inputText1);
            int value2 = Integer.parseInt(inputText2);

            // Find the largest number
            int largestNumber = Math.max(value1, value2);

            // Display the result in the result field
            resultField.setText(String.valueOf(largestNumber));
        } catch (NumberFormatException ex) {
            // Handle invalid input (non-integer)
            JOptionPane.showMessageDialog(this, "Invalid input. Please enter valid integers.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new LargestNumberSwingApp();
            }
        });
    }
}

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CircleAreaSwingApp extends JFrame {

    private JTextField radiusField;
    private JTextField resultField;

    public CircleAreaSwingApp() {
        // Set up the JFrame
        setTitle("Circle Area Calculator");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 150);
        setLayout(new GridLayout(3, 1));

        // Create components
        JLabel radiusLabel = new JLabel("Enter Radius:");
        radiusField = new JTextField();
        JLabel resultLabel = new JLabel("Area of Circle:");
        resultField = new JTextField();
        resultField.setEditable(false); // Make result field read-only

        JButton calculateButton = new JButton("Calculate Area");
        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                calculateCircleArea();
            }
        });

        // Add components to the frame
        add(radiusLabel);
        add(radiusField);
        add(calculateButton);
        add(resultLabel);
        add(resultField);

        // Set up the JFrame visibility
        setLocationRelativeTo(null); // Center the frame on the screen
        setVisible(true);
    }

    private void calculateCircleArea() {
        try {
            // Get the radius value from the input field
            String radiusText = radiusField.getText().trim();

            // Parse the input text to a double
            double radius = Double.parseDouble(radiusText);

            // Calculate the area of the circle
            double area = Math.PI * Math.pow(radius, 2);

            // Display the result in the result field
            resultField.setText(String.format("%.2f", area));
        } catch (NumberFormatException ex) {
            // Handle invalid input (non-numeric)
            JOptionPane.showMessageDialog(this, "Invalid input. Please enter a valid numeric value for the radius.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new CircleAreaSwingApp();
            }
        });
    }
}

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MedicalBillGenerator extends JFrame {
    private JTextField patientIdField, patientNameField, totalAmountField;
    private JCheckBox xRayCheckBox, bloodTestCheckBox, ultrasoundCheckBox;

    public MedicalBillGenerator() {
        setTitle("Medical Bill Generator");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create text fields
        patientIdField = new JTextField(15);
        patientNameField = new JTextField(15);
        totalAmountField = new JTextField(15);
        totalAmountField.setEditable(false); // Make result field read-only

        // Create checkboxes
        xRayCheckBox = new JCheckBox("X-ray");
        bloodTestCheckBox = new JCheckBox("Blood Test");
        ultrasoundCheckBox = new JCheckBox("Ultrasound Scanning");

        // Create button
        JButton billButton = new JButton("Bill");

        // Add action listener to the button
        billButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                generateBill();
            }
        });

        // Create layout
        JPanel panel = new JPanel(new GridLayout(5, 2));
        panel.add(new JLabel("Patient ID:"));
        panel.add(patientIdField);
        panel.add(new JLabel("Patient Name:"));
        panel.add(patientNameField);
        panel.add(new JLabel("Select Tests:"));
        panel.add(new JLabel(""));
        panel.add(xRayCheckBox);
        panel.add(new JLabel(""));
        panel.add(bloodTestCheckBox);
        panel.add(new JLabel(""));
        panel.add(ultrasoundCheckBox);
        panel.add(new JLabel(""));
        panel.add(new JLabel("Total Amount:"));
        panel.add(totalAmountField);
        panel.add(new JLabel(""));
        panel.add(billButton);

        // Set layout for the frame
        setLayout(new BorderLayout());
        add(panel, BorderLayout.CENTER);

        // Set visibility
        setVisible(true);
    }

    private void generateBill() {
        double totalAmount = 0;

        // Check which checkboxes are selected
        if (xRayCheckBox.isSelected()) {
            totalAmount += 50; // Assuming X-ray cost is Rs. 50
        }

        if (bloodTestCheckBox.isSelected()) {
            totalAmount += 30; // Assuming Blood Test cost is Rs. 30
        }

        if (ultrasoundCheckBox.isSelected()) {
            totalAmount += 100; // Assuming Ultrasound Scanning cost is Rs. 100
        }

        // Display the total amount in the text field
        totalAmountField.setText(String.valueOf(totalAmount));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MedicalBillGenerator());
    }
}

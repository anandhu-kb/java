import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ReverseNumberSwingApp extends JFrame {

    private JTextField inputField;
    private JTextField resultField;

    public ReverseNumberSwingApp() {
        // Set up the JFrame
        setTitle("Number Reversal App");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 150);
        setLayout(new GridLayout(3, 1));

        // Create components
        JLabel inputLabel = new JLabel("Enter an Integer:");
        inputField = new JTextField();
        JLabel resultLabel = new JLabel("Reversed Number:");
        resultField = new JTextField();
        resultField.setEditable(false); // Make result field read-only

        JButton reverseButton = new JButton("Reverse");
        reverseButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                reverseNumber();
            }
        });

        // Add components to the frame
        add(inputLabel);
        add(inputField);
        add(reverseButton);
        add(resultLabel);
        add(resultField);

        // Set up the JFrame visibility
        setLocationRelativeTo(null); // Center the frame on the screen
        setVisible(true);
    }

    private void reverseNumber() {
        try {
            // Get the input text from the input field
            String inputText = inputField.getText().trim();

            // Parse the input text to an integer
            int number = Integer.parseInt(inputText);

            // Reverse the number
            int reversedNumber = reverseInteger(number);

            // Display the reversed number in the result field
            resultField.setText(String.valueOf(reversedNumber));
        } catch (NumberFormatException ex) {
            // Handle invalid input (non-integer)
            JOptionPane.showMessageDialog(this, "Invalid input. Please enter a valid integer.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private int reverseInteger(int number) {
        int reversedNumber = 0;
        while (number != 0) {
            int digit = number % 10;
            reversedNumber = reversedNumber * 10 + digit;
            number /= 10;
        }
        return reversedNumber;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new ReverseNumberSwingApp();
            }
        });
    }
}

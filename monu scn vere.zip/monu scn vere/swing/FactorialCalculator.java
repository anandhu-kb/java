import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FactorialCalculator extends JFrame {
    private JTextField inputField, resultField;

    public FactorialCalculator() {
        setTitle("Factorial Calculator");
        setSize(300, 150);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create text fields
        inputField = new JTextField(10);
        resultField = new JTextField(10);
        resultField.setEditable(false); // Make result field read-only

        // Create label
        JLabel inputLabel = new JLabel("Enter an integer:");

        // Create button
        JButton calculateButton = new JButton("Calculate Factorial");

        // Add action listener to the button
        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                calculateFactorial();
            }
        });

        // Create layout
        JPanel panel = new JPanel(new GridLayout(3, 2));
        panel.add(inputLabel);
        panel.add(inputField);
        panel.add(new JLabel("Factorial:"));
        panel.add(resultField);
        panel.add(new JLabel(""));
        panel.add(calculateButton);

        // Set layout for the frame
        setLayout(new BorderLayout());
        add(panel, BorderLayout.CENTER);

        // Set visibility
        setVisible(true);
    }

    private void calculateFactorial() {
        try {
            int inputValue = Integer.parseInt(inputField.getText());

            if (inputValue < 0) {
                JOptionPane.showMessageDialog(this, "Please enter a non-negative integer.", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            long factorialResult = calculateRecursiveFactorial(inputValue);
            resultField.setText(String.valueOf(factorialResult));
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid input. Please enter a valid integer.", "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private long calculateRecursiveFactorial(int n) {
        if (n == 0 || n == 1) {
            return 1;
        } else {
            return n * calculateRecursiveFactorial(n - 1);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new FactorialCalculator());
    }
}

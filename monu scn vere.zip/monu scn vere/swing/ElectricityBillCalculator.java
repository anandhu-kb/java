import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ElectricityBillCalculator extends JFrame {
    private JTextField consumerNoField, consumerNameField, currentReadingField, previousReadingField, unitsConsumedField, totalAmountField, billAmountField;
    private JCheckBox domesticCheckBox, commercialCheckBox;

    public ElectricityBillCalculator() {
        setTitle("Electricity Bill Calculator");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create text fields
        consumerNoField = new JTextField(15);
        consumerNameField = new JTextField(15);
        currentReadingField = new JTextField(15);
        previousReadingField = new JTextField(15);
        unitsConsumedField = new JTextField(15);
        totalAmountField = new JTextField(15);
        billAmountField = new JTextField(15);
        billAmountField.setEditable(false); // Make result field read-only

        // Create checkboxes
        domesticCheckBox = new JCheckBox("Domestic");
        commercialCheckBox = new JCheckBox("Commercial");

        // Create button
        JButton calculateButton = new JButton("Calculate Bill");

        // Add action listener to the button
        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                calculateBill();
            }
        });

        // Create layout
        JPanel panel = new JPanel(new GridLayout(9, 2));
        panel.add(new JLabel("Consumer No.:"));
        panel.add(consumerNoField);
        panel.add(new JLabel("Consumer Name:"));
        panel.add(consumerNameField);
        panel.add(new JLabel("Current Reading:"));
        panel.add(currentReadingField);
        panel.add(new JLabel("Previous Reading:"));
        panel.add(previousReadingField);
        panel.add(new JLabel("Units Consumed:"));
        panel.add(unitsConsumedField);
        panel.add(new JLabel("Total Amount:"));
        panel.add(totalAmountField);
        panel.add(new JLabel("Consumer Type:"));
        panel.add(domesticCheckBox);
        panel.add(new JLabel(""));
        panel.add(commercialCheckBox);
        panel.add(new JLabel("Bill Amount:"));
        panel.add(billAmountField);
        panel.add(new JLabel(""));
        panel.add(calculateButton);

        // Set layout for the frame
        setLayout(new BorderLayout());
        add(panel, BorderLayout.CENTER);

        // Set visibility
        setVisible(true);
    }

    private void calculateBill() {
        try {
            int currentReading = Integer.parseInt(currentReadingField.getText());
            int previousReading = Integer.parseInt(previousReadingField.getText());

            if (currentReading < previousReading) {
                JOptionPane.showMessageDialog(this, "Invalid readings. Current reading should be greater than previous reading.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int unitsConsumed = currentReading - previousReading;
            unitsConsumedField.setText(String.valueOf(unitsConsumed));

            double totalAmount;
            if (domesticCheckBox.isSelected()) {
                totalAmount = (unitsConsumed <= 100) ? unitsConsumed * 2 : (100 * 2) + ((unitsConsumed - 100) * 3);
            } else if (commercialCheckBox.isSelected()) {
                totalAmount = (unitsConsumed <= 100) ? unitsConsumed * 4 : (100 * 4) + ((unitsConsumed - 100) * 8);
            } else {
                JOptionPane.showMessageDialog(this, "Please select a consumer type (Domestic or Commercial).", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            totalAmountField.setText(String.valueOf(totalAmount));
            billAmountField.setText(String.valueOf(totalAmount));
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid input. Please enter valid numerical values.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ElectricityBillCalculator());
    }
}

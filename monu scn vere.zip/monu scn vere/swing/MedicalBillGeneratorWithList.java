import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MedicalBillGeneratorWithList extends JFrame {
    private JTextField patientIdField, patientNameField, totalAmountField;
    private JList<String> medicalServicesList;
    private static final String[] medicalServices = {"X-ray", "Blood Test", "Ultrasound Scanning"};

    public MedicalBillGeneratorWithList() {
        setTitle("Medical Bill Generator");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create text fields
        patientIdField = new JTextField(15);
        patientNameField = new JTextField(15);
        totalAmountField = new JTextField(15);
        totalAmountField.setEditable(false); // Make result field read-only

        // Create list
        medicalServicesList = new JList<>(medicalServices);
        medicalServicesList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);

        // Create button
        JButton billButton = new JButton("Bill");

        // Add action listener to the button
        billButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                generateBill();
            }
        });

        // Create layout
        JPanel panel = new JPanel(new GridLayout(4, 2));
        panel.add(new JLabel("Patient ID:"));
        panel.add(patientIdField);
        panel.add(new JLabel("Patient Name:"));
        panel.add(patientNameField);
        panel.add(new JLabel("Select Medical Services:"));
        panel.add(new JScrollPane(medicalServicesList));
        panel.add(new JLabel("Total Amount:"));
        panel.add(totalAmountField);
        panel.add(new JLabel(""));
        panel.add(billButton);

        // Set layout for the frame
        setLayout(new BorderLayout());
        add(panel, BorderLayout.CENTER);

        // Set visibility
        setVisible(true);
    }

    private void generateBill() {
        int[] selectedIndices = medicalServicesList.getSelectedIndices();
        double totalAmount = 0;

        for (int index : selectedIndices) {
            switch (index) {
                case 0:
                    totalAmount += 50; // Assuming X-ray cost is Rs. 50
                    break;
                case 1:
                    totalAmount += 30; // Assuming Blood Test cost is Rs. 30
                    break;
                case 2:
                    totalAmount += 100; // Assuming Ultrasound Scanning cost is Rs. 100
                    break;
            }
        }

        // Display the total amount in the text field
        totalAmountField.setText(String.valueOf(totalAmount));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MedicalBillGeneratorWithList());
    }
}

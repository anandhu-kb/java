import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.*;

public class FirstSwingExample {
    public static void main(String[] args) {
        JFrame frame = new JFrame("My First Swing Example");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 200);

        JLabel label = new JLabel("Hello, Swing!");
        frame.getContentPane().add(label);

        frame.setVisible(true);
    }
}